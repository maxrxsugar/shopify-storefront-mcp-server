import asyncio
import httpx
import json
import time
from typing import Dict, Any


async def test_endpoint(
    base_url: str = "http://localhost:8000",
    product_name: str = "Test Product"
):
    """Test the endpoint directly without OpenAI"""
    
    async with httpx.AsyncClient(timeout=60.0) as client:
        print(f"\n{'='*60}")
        print(f"🧪 Testing endpoint: {base_url}/get-product-details")
        print(f"📦 Product name: {product_name}")
        print(f"{'='*60}\n")
        
        # Test 1: Regular endpoint with debug info
        print("Test 1: Regular endpoint with debug info")
        print("-" * 40)
        start_time = time.time()
        
        try:
            response = await client.post(
                f"{base_url}/get-product-details",
                json={
                    "productName": product_name,
                    "include_debug": True
                }
            )
            
            elapsed = time.time() - start_time
            print(f"✅ Response received in {elapsed:.3f}s")
            print(f"📊 Status code: {response.status_code}")
            
            data = response.json()
            
            # Extract debug info
            if "_debug" in data:
                debug = data["_debug"]
                print(f"\n📈 Debug Information:")
                print(f"  - Cache hit: {debug.get('cache_hit', 'N/A')}")
                print(f"  - Cache check time: {debug.get('cache_check_time', 'N/A'):.3f}s")
                print(f"  - Shopify query time: {debug.get('shopify_query_time', 'N/A')}")
                print(f"  - Processing time: {debug.get('processing_time', 'N/A')}")
                print(f"  - Response size: {debug.get('response_size_kb', 'N/A')} KB")
                print(f"  - Total time: {debug.get('total_time', 'N/A'):.3f}s")
            
            # Show product info
            print(f"\n📦 Product Information:")
            print(f"  - Title: {data.get('title', 'N/A')}")
            print(f"  - Price: {data.get('price', 'N/A')}")
            print(f"  - Available: {data.get('available', 'N/A')}")
            print(f"  - Variants: {len(data.get('variants', []))}")
            print(f"  - Images: {len(data.get('images', []))}")
            
        except httpx.TimeoutException:
            print(f"❌ Request timed out after {time.time() - start_time:.3f}s")
        except Exception as e:
            print(f"❌ Error: {str(e)}")
        
        print("\n")
        
        # Test 2: Minimal endpoint
        print("Test 2: Minimal endpoint")
        print("-" * 40)
        start_time = time.time()
        
        try:
            response = await client.post(
                f"{base_url}/get-product-details-minimal",
                json={"productName": product_name}
            )
            
            elapsed = time.time() - start_time
            print(f"✅ Response received in {elapsed:.3f}s")
            
            data = response.json()
            response_size = len(json.dumps(data).encode('utf-8'))
            print(f"📊 Response size: {response_size} bytes ({response_size/1024:.2f} KB)")
            print(f"📦 Data: {json.dumps(data, indent=2)}")
            
        except Exception as e:
            print(f"❌ Error: {str(e)}")
        
        print("\n")
        
        # Test 3: Cached endpoint
        print("Test 3: Cached endpoint (mock)")
        print("-" * 40)
        start_time = time.time()
        
        try:
            response = await client.post(
                f"{base_url}/get-product-details-cached",
                json={"productName": product_name}
            )
            
            elapsed = time.time() - start_time
            print(f"✅ Response received in {elapsed:.3f}s")
            print(f"📦 This should be instant: {elapsed < 0.1}")
            
        except Exception as e:
            print(f"❌ Error: {str(e)}")
        
        print("\n")
        
        # Test 4: Debug timing endpoint
        print("Test 4: System timing analysis")
        print("-" * 40)
        
        try:
            response = await client.get(f"{base_url}/debug/timing")
            data = response.json()
            
            print(f"⏱️  System Performance:")
            for key, value in data.items():
                if isinstance(value, dict):
                    print(f"  - {key}:")
                    for k, v in value.items():
                        print(f"      {k}: {v}")
                else:
                    print(f"  - {key}: {value}")
            
        except Exception as e:
            print(f"❌ Error: {str(e)}")
        
        print("\n")
        
        # Test 5: Multiple rapid requests
        print("Test 5: Multiple rapid requests (stress test)")
        print("-" * 40)
        
        async def make_request(i: int):
            start = time.time()
            try:
                response = await client.post(
                    f"{base_url}/get-product-details",
                    json={"productName": f"{product_name} {i}"}
                )
                return time.time() - start, response.status_code
            except:
                return time.time() - start, "error"
        
        # Make 5 concurrent requests
        tasks = [make_request(i) for i in range(5)]
        results = await asyncio.gather(*tasks)
        
        for i, (duration, status) in enumerate(results):
            print(f"  Request {i+1}: {duration:.3f}s - Status: {status}")
        
        avg_time = sum(r[0] for r in results) / len(results)
        print(f"\n  Average response time: {avg_time:.3f}s")


async def simulate_openai_timeout():
    """Simulate OpenAI's timeout behavior"""
    print("\n" + "="*60)
    print("🤖 Simulating OpenAI function call timeout")
    print("="*60 + "\n")
    
    async with httpx.AsyncClient(timeout=45.0) as client:  # OpenAI's timeout
        start_time = time.time()
        
        try:
            print("⏳ Making request with 45s timeout (like OpenAI)...")
            response = await client.post(
                "http://localhost:8000/get-product-details",
                json={
                    "productName": "RxSugar Cereal Pro",
                    "include_debug": True
                }
            )
            
            elapsed = time.time() - start_time
            print(f"✅ Success! Response received in {elapsed:.3f}s")
            
            data = response.json()
            if "_debug" in data:
                print(f"\n🔍 Where time was spent:")
                debug = data["_debug"]
                
                times = [
                    ("Cache check", debug.get("cache_check_time", 0)),
                    ("Shopify query", debug.get("shopify_query_time", 0)),
                    ("Processing", debug.get("processing_time", 0)),
                    ("Cache store", debug.get("cache_store_time", 0))
                ]
                
                for name, duration in times:
                    if duration:
                        percentage = (duration / debug.get("total_time", 1)) * 100
                        print(f"  - {name}: {duration:.3f}s ({percentage:.1f}%)")
            
        except httpx.TimeoutException:
            elapsed = time.time() - start_time
            print(f"❌ TIMEOUT after {elapsed:.3f}s - This is what OpenAI experiences!")
            print("\nPossible causes:")
            print("  1. Cold start (if using free hosting)")
            print("  2. Slow Shopify API response")
            print("  3. Large response size")
            print("  4. Network latency")
            
        except Exception as e:
            print(f"❌ Error: {str(e)}")


if __name__ == "__main__":
    import sys
    
    # Get product name from command line or use default
    product_name = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "Test Product"
    
    # Run tests
    asyncio.run(test_endpoint(product_name=product_name))
    
    # Simulate OpenAI timeout
    asyncio.run(simulate_openai_timeout())
