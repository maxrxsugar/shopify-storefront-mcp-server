import httpx
import json
from typing import Optional, Dict, Any
import time


class ShopifyClient:
    """Async Shopify GraphQL client with connection pooling"""
    
    def __init__(self, store_domain: str, access_token: str):
        self.store_domain = store_domain
        self.access_token = access_token
        self.graphql_endpoint = f"https://{store_domain}/api/2025-07/graphql.json"
        
        # Create persistent client with connection pooling
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(30.0, connect=5.0),
            limits=httpx.Limits(
                max_keepalive_connections=10,
                max_connections=20,
                keepalive_expiry=30.0
            ),
            http2=True  # Enable HTTP/2 for better performance
        )
        
        # GraphQL queries
        self.PRODUCT_QUERY = """
        query getProduct($handle: String!) {
            product(handle: $handle) {
                id
                title
                handle
                description
                availableForSale
                priceRange {
                    minVariantPrice {
                        amount
                        currencyCode
                    }
                    maxVariantPrice {
                        amount
                        currencyCode
                    }
                }
                images(first: 10) {
                    edges {
                        node {
                            url
                            altText
                            width
                            height
                        }
                    }
                }
                variants(first: 20) {
                    edges {
                        node {
                            id
                            title
                            availableForSale
                            price {
                                amount
                                currencyCode
                            }
                            selectedOptions {
                                name
                                value
                            }
                        }
                    }
                }
                seo {
                    title
                    description
                }
                tags
                vendor
                productType
            }
        }
        """
        
        self.MINIMAL_PRODUCT_QUERY = """
        query getProductMinimal($handle: String!) {
            product(handle: $handle) {
                id
                title
                handle
                availableForSale
                priceRange {
                    minVariantPrice {
                        amount
                        currencyCode
                    }
                }
            }
        }
        """
    
    async def execute_query(self, query: str, variables: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a GraphQL query with timing and error handling"""
        start_time = time.time()
        
        try:
            response = await self.client.post(
                self.graphql_endpoint,
                headers={
                    "X-Shopify-Storefront-Access-Token": self.access_token,
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
                json={
                    "query": query,
                    "variables": variables
                }
            )
            
            query_time = time.time() - start_time
            print(f"⚡ GraphQL query completed in {query_time:.3f}s")
            
            # Check for HTTP errors
            response.raise_for_status()
            
            # Parse response
            data = response.json()
            
            # Check for GraphQL errors
            if "errors" in data:
                print(f"❌ GraphQL errors: {data['errors']}")
                raise Exception(f"GraphQL errors: {data['errors']}")
            
            return data.get("data", {})
            
        except httpx.TimeoutException:
            print(f"⏱️ Query timeout after {time.time() - start_time:.3f}s")
            raise Exception("Shopify query timeout")
        except httpx.HTTPStatusError as e:
            print(f"❌ HTTP error {e.response.status_code}: {e.response.text}")
            raise Exception(f"HTTP error: {e.response.status_code}")
        except Exception as e:
            print(f"❌ Query error: {str(e)}")
            raise
    
    async def get_product_by_handle(self, handle: str, minimal: bool = False) -> Optional[Dict[str, Any]]:
        """Get product by handle with optional minimal query"""
        query = self.MINIMAL_PRODUCT_QUERY if minimal else self.PRODUCT_QUERY
        
        print(f"🔍 Fetching product: {handle} (minimal: {minimal})")
        
        data = await self.execute_query(
            query,
            {"handle": handle}
        )
        
        product = data.get("product")
        
        if product:
            # Log response size for debugging
            product_json = json.dumps(product)
            size_bytes = len(product_json.encode('utf-8'))
            size_kb = round(size_bytes / 1024, 2)
            print(f"📦 Product data size: {size_bytes} bytes ({size_kb} KB)")
        
        return product
    
    async def test_connection(self) -> bool:
        """Test the connection to Shopify"""
        try:
            query = """
            {
                shop {
                    name
                    primaryDomain {
                        url
                    }
                }
            }
            """
            
            data = await self.execute_query(query, {})
            shop_name = data.get("shop", {}).get("name")
            
            if shop_name:
                print(f"✅ Connected to Shopify store: {shop_name}")
                return True
            else:
                print("❌ Failed to connect to Shopify")
                return False
                
        except Exception as e:
            print(f"❌ Connection test failed: {str(e)}")
            return False
    
    async def close(self):
        """Close the HTTP client"""
        await self.client.aclose()
