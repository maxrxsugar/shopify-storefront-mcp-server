import httpx
from typing import Dict, Any, Optional
import asyncio
import json

class EnhancedProductService:
    """Service that combines Shopify data with external API information"""
    
    def __init__(self):
        self.external_client = httpx.AsyncClient(
            timeout=httpx.Timeout(30.0),
            limits=httpx.Limits(max_keepalive_connections=5)
        )
    
    async def get_external_info(self, query: str) -> Dict[str, Any]:
        """
        Get additional information from external API
        This is a placeholder - replace with your actual API call
        """
        # Example using a public API (you'll replace this with your commercial API)
        try:
            # For demo purposes, using Wikipedia API
            # Replace this with your actual commercial API endpoint
            response = await self.external_client.get(
                "https://en.wikipedia.org/api/rest_v1/page/summary/Allulose",
                headers={"User-Agent": "ShopifyMCPDebug/1.0"}
            )
            
            if response.status_code == 200:
                data = response.json()
                return {
                    "summary": data.get("extract", ""),
                    "source": "Wikipedia",
                    "additional_info": {
                        "description": data.get("description", ""),
                        "type": "sweetener"
                    }
                }
            else:
                return {
                    "summary": "External information not available",
                    "source": "fallback"
                }
                
        except Exception as e:
            print(f"❌ External API error: {str(e)}")
            return {
                "summary": "Error fetching external information",
                "error": str(e)
            }
    
    async def enrich_product_data(
        self, 
        shopify_data: Dict[str, Any], 
        query: str
    ) -> Dict[str, Any]:
        """Combine Shopify product data with external information"""
        
        # Get external information
        external_info = await self.get_external_info(query)
        
        # Combine the data
        enriched_data = {
            # Shopify data
            "product": {
                "title": shopify_data.get("title", ""),
                "description": shopify_data.get("description", ""),
                "price": shopify_data.get("price"),
                "available": shopify_data.get("available", False),
                "handle": shopify_data.get("handle", ""),
                "images": shopify_data.get("images", [])
            },
            # External API data
            "enhanced_info": {
                "query": query,
                "summary": external_info.get("summary", ""),
                "source": external_info.get("source", ""),
                "additional_details": external_info.get("additional_info", {})
            },
            # Combined response for the user
            "answer": self._generate_answer(shopify_data, external_info, query)
        }
        
        return enriched_data
    
    def _generate_answer(
        self, 
        shopify_data: Dict[str, Any], 
        external_info: Dict[str, Any], 
        query: str
    ) -> str:
        """Generate a comprehensive answer combining both data sources"""
        
        product_name = shopify_data.get("title", "Product")
        product_desc = shopify_data.get("description", "")
        external_summary = external_info.get("summary", "")
        
        # Build the answer
        answer_parts = []
        
        # Start with product info
        answer_parts.append(f"Based on our product '{product_name}':")
        
        # Add product description if available
        if product_desc:
            answer_parts.append(f"\nProduct Description: {product_desc}")
        
        # Add external information
        if external_summary:
            answer_parts.append(f"\nAdditional Information: {external_summary}")
        
        # Add availability and price
        if shopify_data.get("available"):
            price = shopify_data.get("price", "Price not available")
            answer_parts.append(f"\nThis product is currently available for {price}.")
        else:
            answer_parts.append("\nThis product is currently out of stock.")
        
        return "\n".join(answer_parts)
    
    async def close(self):
        """Close the HTTP client"""
        await self.external_client.aclose()


# Example usage function
async def test_enhanced_service():
    """Test the enhanced service"""
    service = EnhancedProductService()
    
    # Mock Shopify data (this would come from your Shopify API)
    mock_shopify_data = {
        "title": "RxSugar Allulose Sweetener",
        "description": "A natural, zero-calorie sweetener",
        "price": "19.99 USD",
        "available": True,
        "handle": "rxsugar-allulose-sweetener"
    }
    
    # Get enriched data
    result = await service.enrich_product_data(
        mock_shopify_data,
        "What is Allulose"
    )
    
    print(json.dumps(result, indent=2))
    
    await service.close()


if __name__ == "__main__":
    asyncio.run(test_enhanced_service())
