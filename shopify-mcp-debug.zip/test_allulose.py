import asyncio
import httpx
import json
import time


async def test_allulose_query():
    """Test the enhanced endpoint with Allulose query"""
    
    base_url = "http://localhost:8000"
    
    async with httpx.AsyncClient(timeout=60.0) as client:
        print("\n" + "="*60)
        print("🧪 Testing Enhanced Endpoint: What is Allulose?")
        print("="*60 + "\n")
        
        # Test 1: Enhanced endpoint with your specific query
        print("Test 1: Enhanced endpoint - 'What is Allulose'")
        print("-" * 40)
        
        request_data = {
            "productName": "Allulose",  # This will be converted to handle: "allulose"
            "query": "What is Allulose",
            "include_debug": True
        }
        
        start_time = time.time()
        
        try:
            print(f"📤 Sending request:")
            print(f"   Product: {request_data['productName']}")
            print(f"   Query: {request_data['query']}")
            print()
            
            response = await client.post(
                f"{base_url}/get-product-details-enhanced",
                json=request_data
            )
            
            elapsed = time.time() - start_time
            print(f"✅ Response received in {elapsed:.3f}s")
            print(f"📊 Status code: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                
                # Show the answer
                print(f"\n📝 Answer:")
                print("-" * 40)
                if "answer" in data:
                    print(data["answer"])
                print("-" * 40)
                
                # Show product info
                if "product" in data:
                    product = data["product"]
                    print(f"\n📦 Product Information:")
                    print(f"  - Title: {product.get('title', 'N/A')}")
                    print(f"  - Price: {product.get('price', 'N/A')}")
                    print(f"  - Available: {product.get('available', 'N/A')}")
                    print(f"  - Description: {product.get('description', 'N/A')[:100]}...")
                
                # Show enhanced info
                if "enhanced_info" in data:
                    enhanced = data["enhanced_info"]
                    print(f"\n🔍 Enhanced Information:")
                    print(f"  - Source: {enhanced.get('source', 'N/A')}")
                    print(f"  - Summary: {enhanced.get('summary', 'N/A')[:200]}...")
                
                # Show debug info
                if "_debug" in data:
                    debug = data["_debug"]
                    print(f"\n📈 Timing Breakdown:")
                    print(f"  - Shopify query: {debug.get('shopify_query_time', 0):.3f}s")
                    print(f"  - External API: {debug.get('external_api_time', 0):.3f}s")
                    print(f"  - Total time: {debug.get('total_time', 0):.3f}s")
                    print(f"  - Response size: {debug.get('response_size_kb', 0)} KB")
                
            else:
                print(f"❌ Error response:")
                print(json.dumps(response.json(), indent=2))
                
        except httpx.TimeoutException:
            print(f"❌ Request timed out after {time.time() - start_time:.3f}s")
        except Exception as e:
            print(f"❌ Error: {str(e)}")
        
        print("\n")
        
        # Test 2: Try variations of product names
        print("Test 2: Testing product name variations")
        print("-" * 40)
        
        variations = [
            "RxSugar Allulose",
            "Allulose Sweetener",
            "RxSugar Allulose Sweetener"
        ]
        
        for product_name in variations:
            print(f"\n🔍 Trying: '{product_name}'")
            
            try:
                response = await client.post(
                    f"{base_url}/get-product-details",
                    json={"productName": product_name}
                )
                
                if response.status_code == 200:
                    data = response.json()
                    print(f"  ✅ Found: {data.get('title', 'Unknown')}")
                    print(f"  Handle: {data.get('handle', 'N/A')}")
                else:
                    print(f"  ❌ Not found (404)")
                    
            except Exception as e:
                print(f"  ❌ Error: {str(e)}")
        
        print("\n")
        
        # Test 3: Compare response times
        print("Test 3: Response time comparison")
        print("-" * 40)
        
        endpoints = [
            ("/get-product-details", {"productName": "Allulose"}),
            ("/get-product-details-minimal", {"productName": "Allulose"}),
            ("/get-product-details-enhanced", {"productName": "Allulose", "query": "What is Allulose"})
        ]
        
        for endpoint, payload in endpoints:
            start = time.time()
            try:
                response = await client.post(f"{base_url}{endpoint}", json=payload)
                duration = time.time() - start
                size = len(response.text)
                print(f"  {endpoint}: {duration:.3f}s ({size} bytes)")
            except:
                print(f"  {endpoint}: Failed")


async def test_timeout_simulation():
    """Simulate the OpenAI timeout scenario"""
    print("\n" + "="*60)
    print("🤖 Simulating OpenAI-like timeout (45s limit)")
    print("="*60 + "\n")
    
    async with httpx.AsyncClient(timeout=45.0) as client:
        start_time = time.time()
        
        try:
            print("⏳ Making request with 45s timeout...")
            response = await client.post(
                "http://localhost:8000/get-product-details-enhanced",
                json={
                    "productName": "Allulose",
                    "query": "What is Allulose",
                    "include_debug": True
                }
            )
            
            elapsed = time.time() - start_time
            print(f"✅ Success! Response received in {elapsed:.3f}s")
            
            if elapsed > 30:
                print("⚠️  WARNING: Response time > 30s - Getting close to timeout!")
            
        except httpx.TimeoutException:
            elapsed = time.time() - start_time
            print(f"❌ TIMEOUT after {elapsed:.3f}s")
            print("This is what OpenAI experiences!")


if __name__ == "__main__":
    print("🚀 Starting Allulose Product Tests")
    print("Make sure the server is running on http://localhost:8000")
    print()
    
    # Run the tests
    asyncio.run(test_allulose_query())
    asyncio.run(test_timeout_simulation())
    
    print("\n✅ Tests complete!")
