#!/usr/bin/env python3
"""
Test the complete flow: User question → OpenAI → MCP Server → OpenAI → Human response
"""

import asyncio
import json
import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

# Initialize OpenAI client
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

def test_openai_with_function():
    """Test OpenAI function calling with your MCP server"""
    
    # Define the function for OpenAI
    functions = [{
        "type": "function",
        "function": {
            "name": "get_product_details",
            "description": "Get detailed product information from RxSugar store including ingredients, benefits, and nutritional information",
            "parameters": {
                "type": "object",
                "properties": {
                    "productName": {
                        "type": "string",
                        "description": "The product name to search for"
                    }
                },
                "required": ["productName"]
            }
        }
    }]
    
    # Test queries
    test_queries = [
        "What is allulose and what are its benefits?",
        "Tell me about the RxSugar Allulose product",
        "Is allulose safe for diabetics?",
        "What ingredients are in the allulose sweetener?",
        "How does allulose compare to regular sugar?"
    ]
    
    print("🤖 Testing OpenAI + MCP Server Integration")
    print("=" * 60)
    
    for i, query in enumerate(test_queries, 1):
        print(f"\n{i}. Testing: '{query}'")
        print("-" * 40)
        
        try:
            # Create chat completion with function calling
            response = client.chat.completions.create(
                model="gpt-4o",  # or "gpt-3.5-turbo"
                messages=[
                    {
                        "role": "system", 
                        "content": "You are a helpful assistant for RxSugar customers. When users ask about products, use the get_product_details function to get accurate information, then provide a friendly, informative response about the product's benefits and ingredients."
                    },
                    {"role": "user", "content": query}
                ],
                tools=functions,
                tool_choice="auto",
                timeout=60  # 60 second timeout
            )
            
            # Check if function was called
            if response.choices[0].message.tool_calls:
                print("✅ Function called successfully")
                function_call = response.choices[0].message.tool_calls[0]
                print(f"   Function: {function_call.function.name}")
                print(f"   Arguments: {function_call.function.arguments}")
                
                # Simulate the function response (your MCP server would return this)
                # In practice, OpenAI handles this automatically
                print("\n📝 OpenAI Response:")
                print(response.choices[0].message.content or "[Waiting for function result...]")
                
            else:
                print("❌ No function called")
                print(f"Response: {response.choices[0].message.content}")
                
        except Exception as e:
            print(f"❌ Error: {e}")
        
        print("\n" + "="*60)

def test_manual_flow():
    """Manually test the flow by calling your server and then OpenAI"""
    import httpx
    
    print("\n🔄 Testing Manual Flow")
    print("=" * 40)
    
    # 1. Call your MCP server
    print("1. Calling MCP server...")
    try:
        response = httpx.post(
            "https://malibu.ngrok.app/get-product-details",
            json={"productName": "RxSugar Allulose Sugar 2 Pound Canister"},
            timeout=30
        )
        product_data = response.json()
        print(f"   ✅ Got product data ({len(str(product_data))} chars)")
        
        # 2. Send to OpenAI for formatting
        print("2. Sending to OpenAI for formatting...")
        
        formatted_response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "system",
                    "content": "You are a helpful assistant. Format the following product information into a friendly, conversational response for a customer asking 'What is allulose?'"
                },
                {
                    "role": "user", 
                    "content": f"Product data: {json.dumps(product_data)}"
                }
            ],
            timeout=60
        )
        
        print("✅ Formatted response received:")
        print("-" * 40)
        print(formatted_response.choices[0].message.content)
        
    except Exception as e:
        print(f"❌ Error in manual flow: {e}")

if __name__ == "__main__":
    # Check if OpenAI API key is set
    if not os.getenv('OPENAI_API_KEY'):
        print("❌ Please set OPENAI_API_KEY in your .env file")
        exit(1)
    
    print("Choose test type:")
    print("1. Test OpenAI function calling (requires Assistant setup)")
    print("2. Test manual flow (MCP → OpenAI formatting)")
    
    choice = input("Enter 1 or 2: ").strip()
    
    if choice == "1":
        test_openai_with_function()
    elif choice == "2":
        test_manual_flow()
    else:
        print("Invalid choice")