from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any


class ProductRequest(BaseModel):
    """Request model for product endpoints"""
    productName: str = Field(..., description="The name of the product to fetch")
    include_debug: bool = Field(default=False, description="Include debug information in response")
    question: Optional[str] = Field(default=None, description="Optional question for intelligent response")


class EnhancedProductRequest(BaseModel):
    """Request model for enhanced product endpoint"""
    productName: str = Field(..., description="The name of the product to fetch")
    query: str = Field(..., description="The question or query about the product")
    include_debug: bool = Field(default=False, description="Include debug information in response")


class ProductResponse(BaseModel):
    """Response model for product data"""
    title: str
    description: Optional[str] = None
    price: Optional[str] = None
    available: bool = False
    handle: Optional[str] = None
    images: List[str] = []
    variants: List[Dict[str, Any]] = []
    _debug: Optional[Dict[str, Any]] = None


class DebugInfo(BaseModel):
    """Debug information model"""
    handle: str
    cache_hit: bool
    cache_check_time: float
    shopify_query_time: Optional[float] = None
    processing_time: Optional[float] = None
    response_size_bytes: Optional[int] = None
    response_size_kb: Optional[float] = None
    cache_store_time: Optional[float] = None
    total_time: float
    error: Optional[str] = None
