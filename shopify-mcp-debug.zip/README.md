# Shopify MCP Debug Server

A FastAPI server designed to debug and optimize Shopify MCP (Model Context Protocol) timeout issues when OpenAI calls your function endpoints.

## 🎯 Purpose

This server helps identify bottlenecks in the Shopify → MCP Server → OpenAI pipeline by providing:
- Detailed timing breakdowns
- Response size analysis
- Caching mechanisms
- Multiple endpoint variations for testing
- Direct testing tools (bypassing OpenAI)

## 🚀 Quick Start

### 1. Install Dependencies

```bash
cd shopify-mcp-debug
pip install -r requirements.txt
```

### 2. Configure Environment

Copy `.env.example` to `.env` and fill in your details:

```bash
cp .env.example .env
```

Edit `.env`:
```env
SHOPIFY_STORE_DOMAIN=your-store.myshopify.com
SHOPIFY_STOREFRONT_ACCESS_TOKEN=your-storefront-access-token
POPULAR_PRODUCTS=product-handle-1,product-handle-2
```

### 3. Run the Server

```bash
python main.py
```

The server will start on `http://localhost:8000`

### 4. Test Locally

Run the test script:
```bash
python test_endpoint.py "Your Product Name"
```

### 5. Expose with Ngrok

In a new terminal:
```bash
ngrok http 8000
```

Use the HTTPS URL from ngrok for your OpenAI function configuration.

## 📊 Endpoints

### Main Endpoints

1. **`POST /get-product-details`** - Main endpoint (replicates production)
   ```json
   {
     "productName": "Product Name",
     "include_debug": true
   }
   ```

2. **`POST /get-product-details-minimal`** - Returns only essential data
   ```json
   {
     "productName": "Product Name"
   }
   ```

3. **`POST /get-product-details-cached`** - Mock cached response for testing

### Debug Endpoints

4. **`GET /debug/timing`** - System performance analysis
5. **`GET /debug/cache-stats`** - Cache statistics
6. **`GET /health`** - Health check (keeps service warm)

## 🔍 Debugging the Timeout Issue

### What to Look For

1. **In the Console Logs:**
   - Total processing time
   - Shopify query time
   - Response size in KB
   - Cache hit/miss status

2. **In the Debug Response:**
   ```json
   {
     "title": "Product Title",
     "price": "19.99 USD",
     "_debug": {
       "cache_hit": false,
       "shopify_query_time": 1.234,
       "response_size_kb": 45.2,
       "total_time": 1.567
     }
   }
   ```

### Common Issues & Solutions

#### 1. **Cold Start (Render/Heroku)**
- **Symptom:** First request takes 30-45 seconds
- **Solution:** Use the health endpoint with external monitoring to keep warm

#### 2. **Large Response Size**
- **Symptom:** Response > 50KB, parsing delays
- **Solution:** Use the minimal endpoint or reduce data returned

#### 3. **Slow Shopify Queries**
- **Symptom:** `shopify_query_time` > 5 seconds
- **Solution:** Simplify GraphQL query, add caching

#### 4. **Network Latency**
- **Symptom:** Fast locally, slow in production
- **Solution:** Deploy closer to Shopify's servers (US East Coast)

## 🛠️ Optimization Strategies

### 1. Enable Caching
Products are cached for 5 minutes by default. Popular products can be pre-cached on startup.

### 2. Use Minimal Responses
The `/get-product-details-minimal` endpoint returns only essential data:
- Title
- Price
- Availability

### 3. Keep Service Warm
Set up a cron job or monitoring service to hit `/health` every 5 minutes.

### 4. Response Size Limits
Keep responses under 50KB for optimal OpenAI function calling performance.

## 📈 Performance Testing

### Direct Testing (Bypass OpenAI)
```bash
python test_endpoint.py "RxSugar Cereal Pro"
```

This will:
- Test all endpoints
- Show timing breakdowns
- Simulate OpenAI's 45-second timeout
- Run stress tests

### Load Testing
```bash
# Install hey (HTTP load generator)
brew install hey  # macOS
# or
apt-get install hey  # Linux

# Test with 100 requests, 10 concurrent
hey -n 100 -c 10 -m POST -H "Content-Type: application/json" \
  -d '{"productName":"Test Product"}' \
  http://localhost:8000/get-product-details
```

## 🔧 Advanced Configuration

### Custom Cache TTL
Set in `.env`:
```env
CACHE_TTL=600  # 10 minutes
```

### Pre-warm Popular Products
Set in `.env`:
```env
POPULAR_PRODUCTS=best-seller,featured-product,new-arrival
```

### Adjust Timeouts
In `shopify_client.py`:
```python
timeout=httpx.Timeout(30.0, connect=5.0)  # Adjust as needed
```

## 📝 Logs to Share

When debugging with others, share:
1. Console output from the server
2. Response from `/debug/timing`
3. A sample response with `include_debug: true`
4. Results from `test_endpoint.py`

## 🚨 Troubleshooting

### "Product not found"
- Check the product handle format (lowercase, hyphens instead of spaces)
- Verify the product exists in your Shopify store
- Check your Storefront API permissions

### "Connection refused"
- Ensure the server is running
- Check the port isn't already in use
- Verify your firewall settings

### Timeout in test script
- Your Shopify API token might be invalid
- Network connectivity issues
- Shopify API rate limiting

## 🎯 Next Steps

Once you identify the bottleneck:

1. **If it's response size:** Implement the minimal endpoint in production
2. **If it's cold starts:** Upgrade hosting or implement warming
3. **If it's Shopify queries:** Add caching and optimize GraphQL
4. **If it's network latency:** Consider edge deployment

Good luck debugging! 🚀
