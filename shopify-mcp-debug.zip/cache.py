import time
from typing import Dict, Any, Optional
from datetime import datetime


class ProductCache:
    """Simple in-memory cache with TTL support"""
    
    def __init__(self, ttl_seconds: int = 300):  # 5 minutes default
        self.cache: Dict[str, Dict[str, Any]] = {}
        self.ttl_seconds = ttl_seconds
        self.stats = {
            "hits": 0,
            "misses": 0,
            "sets": 0,
            "evictions": 0
        }
    
    def get(self, key: str) -> Optional[Dict[str, Any]]:
        """Get item from cache if not expired"""
        if key in self.cache:
            entry = self.cache[key]
            if time.time() - entry["timestamp"] < self.ttl_seconds:
                self.stats["hits"] += 1
                print(f"💾 Cache hit: {key}")
                return entry["data"]
            else:
                # Expired, remove it
                del self.cache[key]
                self.stats["evictions"] += 1
                print(f"⏰ Cache expired: {key}")
        
        self.stats["misses"] += 1
        return None
    
    def set(self, key: str, data: Dict[str, Any]) -> None:
        """Set item in cache"""
        self.cache[key] = {
            "data": data,
            "timestamp": time.time()
        }
        self.stats["sets"] += 1
        print(f"💾 Cached: {key}")
    
    def clear(self) -> None:
        """Clear all cache entries"""
        self.cache.clear()
        print("🗑️  Cache cleared")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_requests = self.stats["hits"] + self.stats["misses"]
        hit_rate = (self.stats["hits"] / total_requests * 100) if total_requests > 0 else 0
        
        return {
            "size": len(self.cache),
            "hits": self.stats["hits"],
            "misses": self.stats["misses"],
            "sets": self.stats["sets"],
            "evictions": self.stats["evictions"],
            "hit_rate": f"{hit_rate:.1f}%",
            "ttl_seconds": self.ttl_seconds
        }
    
    def cleanup_expired(self) -> int:
        """Remove expired entries and return count"""
        current_time = time.time()
        expired_keys = [
            key for key, entry in self.cache.items()
            if current_time - entry["timestamp"] >= self.ttl_seconds
        ]
        
        for key in expired_keys:
            del self.cache[key]
            self.stats["evictions"] += 1
        
        if expired_keys:
            print(f"🧹 Cleaned up {len(expired_keys)} expired entries")
        
        return len(expired_keys)
