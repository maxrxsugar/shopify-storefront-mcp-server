# Quick Start Guide - Shopify MCP Debug Server

## Your Setup is Ready! 🎉

Your Shopify store credentials have been configured:
- Store: hydrafacial-loyalty-development.myshopify.com
- API Token: Configured in .env

## Step 1: Install Dependencies

Open a terminal in the `shopify-mcp-debug` directory and run:

```bash
cd shopify-mcp-debug
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Step 2: Start the Server

```bash
python main.py
```

You should see:
```
🚀 Starting up FastAPI server...
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8000
```

## Step 3: Test Locally

In a new terminal window:

```bash
cd shopify-mcp-debug
source venv/bin/activate

# Test basic endpoint
python test_endpoint.py "Your Product Name"

# Test the enhanced "What is Allulose" query
python test_allulose.py
```

Replace "Your Product Name" with an actual product from your store.

## Step 4: Expose with Ngrok

In another terminal:

```bash
ngrok http 8000
```

You'll get a URL like: `https://abc123.ngrok.io`

## Step 5: Configure OpenAI Assistant

Use your ngrok URL for the function endpoint:
- Function URL: `https://abc123.ngrok.io/get-product-details`

## Debugging Tips

### Watch the Server Console
The server logs detailed timing information:
- 🔍 Product lookup attempts
- ⚡ GraphQL query times
- 📊 Response sizes
- ⏱️ Total processing times

### Use Debug Mode
Add `"include_debug": true` to your requests to get timing breakdowns:

```json
{
  "productName": "Test Product",
  "include_debug": true
}
```

### Common Issues

1. **"Product not found"**
   - Product names are converted to handles (lowercase, spaces → hyphens)
   - "My Product" becomes "my-product"

2. **Timeout Issues**
   - Check the console for which step is slow
   - If Shopify query > 5s, you may need to simplify the GraphQL query
   - If response size > 50KB, use the minimal endpoint

3. **Connection Errors**
   - Verify your API token is a Storefront API token (not Admin API)
   - Check that the token has proper permissions

## Test Different Endpoints

1. **Regular endpoint** (full data):
   ```
   POST /get-product-details
   ```

2. **Minimal endpoint** (just title, price, availability):
   ```
   POST /get-product-details-minimal
   ```

3. **Check performance**:
   ```
   GET /debug/timing
   ```

## Need Help?

- Check the main README.md for detailed documentation
- Look at server console logs for error details
- Run `python test_endpoint.py` to test without OpenAI
