import json
import threading
from pathlib import Path
from typing import Dict

METRICS_FILE = Path("metrics.json")
_lock = threading.Lock()

# Initialize metrics if file doesn't exist
if not METRICS_FILE.exists():
    with METRICS_FILE.open("w") as f:
        json.dump({}, f)

def increment_metric(endpoint: str):
    with _lock:
        metrics = load_metrics()
        metrics[endpoint] = metrics.get(endpoint, 0) + 1
        save_metrics(metrics)

def load_metrics() -> Dict[str, int]:
    if METRICS_FILE.exists():
        with METRICS_FILE.open("r") as f:
            return json.load(f)
    return {}

def save_metrics(metrics: Dict[str, int]):
    with METRICS_FILE.open("w") as f:
        json.dump(metrics, f, indent=2)
