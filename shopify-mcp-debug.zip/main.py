import os
import time
import json
import asyncio
from datetime import datetime
from typing import Optional, Dict, Any
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import httpx
import uvicorn
from dotenv import load_dotenv

from shopify_client import ShopifyClient
from cache import ProductCache
from models import ProductRequest, ProductResponse, DebugInfo, EnhancedProductRequest
from enhanced_endpoint import EnhancedProductService
from metrics import increment_metric
from starlette.responses import Response

# Load environment variables
load_dotenv()

# Initialize cache
product_cache = ProductCache()

# Add this after line -- This allows for more intelligent answers from OpenAI otherwise
# Its only product focused
from openai import OpenAI
openai_client: Optional[OpenAI] = None

# Global client instance
shopify_client: Optional[ShopifyClient] = None
enhanced_service: Optional[EnhancedProductService] = None

async def find_product_by_partial_name(client: ShopifyClient, product_name: str) -> Dict[str, Any]:
    """Smart product search that handles partial names"""
    print(f"🔍 Smart search for: '{product_name}'")
    
    # First, try the original method (convert to handle)
    handle = product_name.lower().replace(" ", "-")
    print(f"   📍 Trying handle: '{handle}'")
    
    try:
        result = await client.get_product_by_handle(handle)
        if result:
            print(f"   ✅ Found via handle!")
            return result
    except Exception as e:
        print(f"   ❌ Handle search failed: {e}")
    
    # Define product mappings for common searches
    product_mappings = {
        "allulose": "rxsugar-allulose-sugar-2-pound-canister",
        "sweetener": "rxsugar-allulose-sugar-2-pound-canister", 
        "rxsugar": "rxsugar-allulose-sugar-2-pound-canister",
        "sugar": "rxsugar-allulose-sugar-2-pound-canister",
        "rx-sugar": "rxsugar-allulose-sugar-2-pound-canister",
        "allullose": "rxsugar-allulose-sugar-2-pound-canister",  # common misspelling
    }
    
    # Check if the search term matches any keywords
    search_lower = product_name.lower().strip()
    print(f"   🔍 Checking keywords for: '{search_lower}'")
    
    for keyword, product_handle in product_mappings.items():
        if keyword in search_lower or search_lower in keyword:
            print(f"   🎯 Keyword match: '{keyword}' -> '{product_handle}'")
            try:
                result = await client.get_product_by_handle(product_handle)
                if result:
                    print(f"   ✅ Found via keyword mapping!")
                    return result
            except Exception as e:
                print(f"   ❌ Keyword mapping failed: {e}")
                continue
    
    # No matches found
    print(f"   ❌ No products found for '{product_name}'")
    return None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle"""
    global shopify_client, enhanced_service, openai_client  
    
    # Startup
    print("🚀 Starting up FastAPI server...")
    shopify_client = ShopifyClient(
        store_domain=os.getenv("SHOPIFY_STORE_DOMAIN"),
        access_token=os.getenv("SHOPIFY_STOREFRONT_ACCESS_TOKEN")
    )
    
    # Initialize enhanced service
    enhanced_service = EnhancedProductService()
    
    # Add OpenAI client initialization
    openai_api_key = os.getenv("OPENAI_API_KEY")
    if openai_api_key:
        openai_client = OpenAI(api_key=openai_api_key)
        print("✅ OpenAI client initialized")
    else:
        print("⚠️ No OpenAI API key - intelligent responses disabled")
    
    # Warm up cache with popular products if specified
    popular_products = os.getenv("POPULAR_PRODUCTS", "").split(",")
    if popular_products and popular_products[0]:
        print("🔥 Warming up cache...")
        for handle in popular_products:
            try:
                await shopify_client.get_product_by_handle(handle.strip())
                print(f"  ✓ Cached: {handle}")
            except Exception as e:
                print(f"  ✗ Failed to cache {handle}: {e}")
    
    yield
    
    # Shutdown
    print("👋 Shutting down...")
    await shopify_client.close()
    await enhanced_service.close()

# Simple in-memory metrics
metrics_store = {
    "total_requests": 0,
    "endpoints": {}
}

app = FastAPI(
    title="Shopify MCP Debug Server",
    version="1.0.0",
    lifespan=lifespan
)

# Configure CORS for OpenAI
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = time.time()
    path = request.url.path

    # Skip logging for noisy paths
    if path.startswith("/assets") or path.endswith(".js") or path.endswith(".css") or path.endswith(".map"):
        return await call_next(request)

    # Process request
    response = await call_next(request)

    # Read body safely
    response_body = b""
    async for chunk in response.body_iterator:
        response_body += chunk

    # Recreate response with original body
    new_response = Response(
        content=response_body,
        status_code=response.status_code,
        headers=dict(response.headers),
        media_type=response.media_type
    )

    duration = time.time() - start_time
    content_length = len(response_body)

    # Log + track metrics
    metrics_store["total_requests"] += 1
    if path not in metrics_store["endpoints"]:
        metrics_store["endpoints"][path] = {
            "count": 0,
            "avg_response_time": 0,
            "total_characters": 0
        }

    ep_metrics = metrics_store["endpoints"][path]
    ep_metrics["count"] += 1
    ep_metrics["total_characters"] += content_length
    n = ep_metrics["count"]
    ep_metrics["avg_response_time"] = (
        ((n - 1) * ep_metrics["avg_response_time"] + duration) / n
    )

    print(f"\n{'='*50}")
    print(f"📥 {request.method} {path}")
    print(f"🕐 {datetime.now().isoformat()}")
    print(f"⏱️  Response time: {duration:.3f}s, Size: {content_length} chars")
    print(f"{'='*50}\n")

    return new_response


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Shopify MCP Debug Server",
        "status": "running",
        "endpoints": [
            "/health",
            "/get-product-details",
            "/get-product-details-minimal",
            "/get-product-details-cached",
            "/get-product-details-enhanced",
            "/debug/timing",
            "/debug/cache-stats"
        ]
    }


@app.get("/health")
async def health_check():
    """Health check endpoint to keep service warm"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "cache_size": len(product_cache.cache),
        "shopify_connected": shopify_client is not None
    }

@app.post("/ask-question")
async def ask_question(request: dict) -> Dict[str, Any]:
    """Complete question-answering endpoint that mimics the manual flow"""
    question = request.get("question", "")
    
    # Step 1: Get product data
    product_data = await find_product_by_partial_name(shopify_client, "allulose")
    
    # Step 2: Send to OpenAI for formatting
    formatted_response = await client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {
                "role": "system",
                "content": "You are a helpful assistant. Format the following product information into a friendly, conversational response."
            },
            {
                "role": "user", 
                "content": f"Question: {question}\n\nProduct data: {json.dumps(product_data)}"
            }
        ],
        timeout=60
    )
    
    return {
        "question": question,
        "response": formatted_response.choices[0].message.content
    }

@app.post("/get-product-details")
async def get_product_details(request: ProductRequest) -> Dict[str, Any]:
    """Main endpoint - replicates the production endpoint"""
    start_time = time.time()
    debug_info = {}
    
    try:
        print(f"🔍 Getting product details for: {request.productName}")
        
        # Convert product name to handle
        handle = request.productName.lower().replace(" ", "-")
        debug_info["handle"] = handle
        
        # Check cache first
        cache_start = time.time()
        cached_data = product_cache.get(handle)
        debug_info["cache_check_time"] = time.time() - cache_start
        
        if cached_data:
            print(f"✅ Cache hit for: {handle}")
            debug_info["cache_hit"] = True
            debug_info["total_time"] = time.time() - start_time
            
            # Add debug info if requested
            if request.include_debug:
                cached_data["_debug"] = debug_info
            
            return cached_data
        
        print(f"❌ Cache miss for: {handle}")
        debug_info["cache_hit"] = False
        
        # Fetch from Shopify
        shopify_start = time.time()
        product_data = await find_product_by_partial_name(shopify_client, request.productName)
        debug_info["shopify_query_time"] = time.time() - shopify_start
        
        if not product_data:
            raise HTTPException(status_code=404, detail="Product not found")
        
        # Process response
        process_start = time.time()
        response = {
            "title": product_data.get("title", ""),
            "description": product_data.get("description", ""),
            "price": extract_price(product_data),
            "available": product_data.get("availableForSale", False),
            "handle": product_data.get("handle", ""),
            "images": extract_images(product_data, limit=3),
            "variants": extract_variants(product_data, limit=5)
        }
        debug_info["processing_time"] = time.time() - process_start
        
        # Measure response size
        response_json = json.dumps(response)
        response_size = len(response_json.encode('utf-8'))
        debug_info["response_size_bytes"] = response_size
        debug_info["response_size_kb"] = round(response_size / 1024, 2)
        
        print(f"📊 Response size: {response_size} bytes ({debug_info['response_size_kb']} KB)")
        
        # Cache the response
        cache_store_start = time.time()
        product_cache.set(handle, response)
        debug_info["cache_store_time"] = time.time() - cache_store_start
        
        # Total time
        debug_info["total_time"] = time.time() - start_time
        print(f"⏱️  Total processing time: {debug_info['total_time']:.3f}s")
        
        # 🔥 ADD THIS BLOCK HERE - OpenAI intelligent formatting
        if hasattr(request, 'question') and request.question and openai_client:
            formatting_start = time.time()
            
            try:
                formatted_response = openai_client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[
                        {
                            "role": "system",
                            "content": "You are a helpful RxSugar customer service assistant. Use the product information to answer customer questions conversationally."
                        },
                        {
                            "role": "user", 
                            "content": f"Question: {request.question}\n\nProduct: {json.dumps(response)}"
                        }
                    ],
                    timeout=30
                )
                
                debug_info["openai_formatting_time"] = time.time() - formatting_start
                
                # Enhance the response with formatted answer
                response["question"] = request.question
                response["intelligent_answer"] = formatted_response.choices[0].message.content
                
            except Exception as e:
                print(f"⚠️ OpenAI formatting failed: {e}")
                debug_info["openai_error"] = str(e)
        
        # Add debug info if requested
        if request.include_debug:
            response["_debug"] = debug_info
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        debug_info["error"] = str(e)
        debug_info["total_time"] = time.time() - start_time
        
        # Return error with debug info
        error_response = {
            "error": "Internal server error",
            "message": str(e)
        }
        if request.include_debug:
            error_response["_debug"] = debug_info
            
        raise HTTPException(status_code=500, detail=error_response)


@app.post("/get-product-details-minimal")
async def get_product_details_minimal(request: ProductRequest) -> Dict[str, Any]:
    """Minimal endpoint - returns only essential data"""
    handle = request.productName.lower().replace(" ", "-")
    
    # Try cache first
    cached_data = product_cache.get(f"{handle}_minimal")
    if cached_data:
        return cached_data
    
    # Fetch from Shopify
    product_data = await shopify_client.get_product_by_handle(handle)
    
    if not product_data:
        raise HTTPException(status_code=404, detail="Product not found")
    
    # Return absolute minimum
    response = {
        "title": product_data.get("title", ""),
        "price": extract_price(product_data),
        "available": product_data.get("availableForSale", False)
    }
    
    # Cache it
    product_cache.set(f"{handle}_minimal", response)
    
    return response


@app.post("/get-product-details-cached")
async def get_product_details_cached(request: ProductRequest) -> Dict[str, Any]:
    """Force cached response for testing"""
    handle = request.productName.lower().replace(" ", "-")
    
    # Return mock cached data immediately
    return {
        "title": f"Cached Product: {request.productName}",
        "description": "This is a cached response for testing purposes",
        "price": "19.99",
        "available": True,
        "handle": handle,
        "_cached": True,
        "_timestamp": datetime.now().isoformat()
    }


@app.post("/get-product-details-enhanced")
async def get_product_details_enhanced(request: EnhancedProductRequest) -> Dict[str, Any]:
    """Enhanced endpoint that combines Shopify data with external API information"""
    start_time = time.time()
    debug_info = {}
    
    try:
        print(f"🔍 Getting enhanced product details for: {request.productName}")
        print(f"❓ Query: {request.query}")
        
        # Convert product name to handle
        handle = request.productName.lower().replace(" ", "-")
        debug_info["handle"] = handle
        debug_info["query"] = request.query
        
        # Check cache for Shopify data
        cache_key = f"{handle}_enhanced"
        cache_start = time.time()
        cached_data = product_cache.get(cache_key)
        debug_info["cache_check_time"] = time.time() - cache_start
        
        if cached_data and not request.include_debug:
            print(f"✅ Cache hit for enhanced data: {handle}")
            return cached_data
        
        # Fetch from Shopify
        shopify_start = time.time()
        product_data = await shopify_client.get_product_by_handle(handle)
        debug_info["shopify_query_time"] = time.time() - shopify_start
        
        if not product_data:
            # Try searching for products containing the name
            print(f"⚠️ No exact match for handle: {handle}")
            raise HTTPException(status_code=404, detail="Product not found")
        
        # Process Shopify data
        process_start = time.time()
        shopify_response = {
            "title": product_data.get("title", ""),
            "description": product_data.get("description", ""),
            "price": extract_price(product_data),
            "available": product_data.get("availableForSale", False),
            "handle": product_data.get("handle", ""),
            "images": extract_images(product_data, limit=3)
        }
        debug_info["shopify_processing_time"] = time.time() - process_start
        
        # Get enhanced information from external API
        external_start = time.time()
        enriched_data = await enhanced_service.enrich_product_data(
            shopify_response,
            request.query
        )
        debug_info["external_api_time"] = time.time() - external_start
        
        # Measure final response size
        response_json = json.dumps(enriched_data)
        response_size = len(response_json.encode('utf-8'))
        debug_info["response_size_bytes"] = response_size
        debug_info["response_size_kb"] = round(response_size / 1024, 2)
        
        print(f"📊 Enhanced response size: {response_size} bytes ({debug_info['response_size_kb']} KB)")
        
        # Cache the enhanced response
        if not request.include_debug:
            cache_store_start = time.time()
            product_cache.set(cache_key, enriched_data)
            debug_info["cache_store_time"] = time.time() - cache_store_start
        
        # Total time
        debug_info["total_time"] = time.time() - start_time
        print(f"⏱️  Total enhanced processing time: {debug_info['total_time']:.3f}s")
        
        # Add debug info if requested
        if request.include_debug:
            enriched_data["_debug"] = debug_info
        
        return enriched_data
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error in enhanced endpoint: {str(e)}")
        debug_info["error"] = str(e)
        debug_info["total_time"] = time.time() - start_time
        
        # Return error with debug info
        error_response = {
            "error": "Internal server error",
            "message": str(e),
            "query": request.query,
            "productName": request.productName
        }
        if request.include_debug:
            error_response["_debug"] = debug_info
            
        raise HTTPException(status_code=500, detail=error_response)


@app.get("/debug/timing")
async def debug_timing():
    """Test various operations and their timing"""
    results = {}
    
    # Test 1: Simple JSON serialization
    start = time.time()
    large_object = {"data": [{"id": i, "value": f"item_{i}" * 100} for i in range(1000)]}
    json_str = json.dumps(large_object)
    results["json_serialization_1000_items"] = {
        "time_seconds": time.time() - start,
        "size_bytes": len(json_str.encode('utf-8'))
    }
    
    # Test 2: Shopify API call
    if shopify_client:
        start = time.time()
        try:
            await shopify_client.get_product_by_handle("test-product")
            results["shopify_api_call"] = time.time() - start
        except:
            results["shopify_api_call"] = "Failed"
    
    # Test 3: Cache operations
    start = time.time()
    for i in range(100):
        product_cache.set(f"test_{i}", {"data": f"test_{i}"})
        product_cache.get(f"test_{i}")
    results["cache_100_operations"] = time.time() - start
    
    return results


@app.get("/debug/cache-stats")
async def cache_stats():
    """Get cache statistics"""
    return {
        "cache_size": len(product_cache.cache),
        "cache_items": list(product_cache.cache.keys()),
        "memory_usage_estimate": sum(
            len(json.dumps(v).encode('utf-8')) 
            for v in product_cache.cache.values()
        )
    }

@app.get("/metrics")
async def get_metrics():
    return metrics_store

def load_metrics():
    # dummy example
    return {"status": "ok", "metrics": {}}


def extract_price(product_data: Dict[str, Any]) -> Optional[str]:
    """Extract price from product data"""
    try:
        price_range = product_data.get("priceRange", {})
        min_price = price_range.get("minVariantPrice", {})
        amount = min_price.get("amount")
        currency = min_price.get("currencyCode", "USD")
        
        if amount:
            return f"{amount} {currency}"
        return None
    except:
        return None


def extract_images(product_data: Dict[str, Any], limit: int = 3) -> list:
    """Extract limited number of image URLs"""
    try:
        images = product_data.get("images", {}).get("edges", [])
        return [
            edge["node"]["url"] 
            for edge in images[:limit]
            if "node" in edge and "url" in edge["node"]
        ]
    except:
        return []


def extract_variants(product_data: Dict[str, Any], limit: int = 5) -> list:
    """Extract limited variant information"""
    try:
        variants = product_data.get("variants", {}).get("edges", [])
        return [
            {
                "id": edge["node"].get("id"),
                "title": edge["node"].get("title"),
                "price": edge["node"].get("price", {}).get("amount"),
                "available": edge["node"].get("availableForSale", False)
            }
            for edge in variants[:limit]
            if "node" in edge
        ]
    except:
        return []


if __name__ == "__main__":
    # Run with uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,        #3030 on local server with ngrok
        reload=True,
        log_level="info"
    )
